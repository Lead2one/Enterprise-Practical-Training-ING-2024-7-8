def get_test():
    print("OSS-SETENV")
